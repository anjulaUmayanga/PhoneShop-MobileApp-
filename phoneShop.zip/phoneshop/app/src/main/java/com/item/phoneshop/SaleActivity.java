package com.item.phoneshop;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class SaleActivity extends AppCompatActivity {

    Button apple,pixel,samsung,sony;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sale);

        apple = findViewById(R.id.apple);
        pixel = findViewById(R.id.pixel);
        samsung = findViewById(R.id.sam);
        sony = findViewById(R.id.son);

        apple.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent1 = new Intent(SaleActivity.this,AppleActivity.class);
                startActivity(intent1);
            }
        });
        pixel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent2 = new Intent(SaleActivity.this,PixelActivity.class);
                startActivity(intent2);
            }
        });
        samsung.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent3 = new Intent(SaleActivity.this , SamsungActivity.class);
                startActivity(intent3);
            }
        });
        sony.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent4 = new Intent(SaleActivity.this,SonyActivity.class);
                startActivity(intent4);
            }
        });

    }
}
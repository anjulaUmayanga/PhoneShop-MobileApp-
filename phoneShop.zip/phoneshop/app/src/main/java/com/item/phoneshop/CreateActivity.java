package com.item.phoneshop;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class CreateActivity extends AppCompatActivity {

    Button log, submit;
    EditText uname,pw;

    @SuppressLint("MissingInflatedId")
    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create);

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef1 = database.getReference("Name");
        DatabaseReference myRef2 = database.getReference("Password");

        log = findViewById(R.id.Login);
        submit = findViewById(R.id.submit);
        uname = findViewById(R.id.Uname);
        pw = findViewById(R.id.PW);

        log.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(CreateActivity.this , MainActivity.class);
                startActivity(intent);
            }
        });
        submit.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                String name = uname.getText().toString();
                String password = pw.getText().toString();
                myRef1.setValue(name);
                myRef2.setValue(password);
                Toast.makeText(CreateActivity.this, "Successfull Regisrter", Toast.LENGTH_SHORT).show();
            }
        });

    }
}
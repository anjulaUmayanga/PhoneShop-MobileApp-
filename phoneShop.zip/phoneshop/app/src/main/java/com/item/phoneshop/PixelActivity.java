package com.item.phoneshop;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class PixelActivity extends AppCompatActivity {
    RadioButton p7p, p8, p8p;
    Button add;
    String type="",price="";
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pixel);
        add = findViewById(R.id.addcart);
        p7p = findViewById(R.id.p7p);
        p8 = findViewById(R.id.p8);
        p8p = findViewById(R.id.p8p);

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef1 = database.getReference("type");
        DatabaseReference myRef2 = database.getReference("price");


        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(p7p.isChecked()){
                    type="Pixel 7 Pro";
                    price="$690";
                } else if (p8.isChecked()) {
                    type="pixel 8";
                    price = "$710";

                }
                else if (p8p.isChecked()) {
                    type="pixel 8 Pro";
                    price = "$1059";

                }else{
                    Toast.makeText(PixelActivity.this, "Please select Phone", Toast.LENGTH_SHORT).show();
                }
                myRef1.setValue(type);
                myRef2.setValue(price);
                Intent in = new Intent(PixelActivity.this,activity_cartview.class);
                startActivity(in);

            }
        });




    }
}
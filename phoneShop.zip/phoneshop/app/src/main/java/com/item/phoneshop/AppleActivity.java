package com.item.phoneshop;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class AppleActivity extends AppCompatActivity {

    String type="";
    String price = "";
    Button addcart;
    RadioButton ip13,ip13p,ip13pm;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_apple);
        addcart = findViewById(R.id.addcart);
        ip13 = findViewById(R.id.n13);
        ip13p = findViewById(R.id.p13p);
        ip13pm = findViewById(R.id.pm);

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef1 = database.getReference("type");
        DatabaseReference myRef2 = database.getReference("price");


        addcart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (ip13.isChecked()){
                    type="Iphone 13";
                    price= "$699";

                }
                else if (ip13p.isChecked()){
                    type="Iphone 13 Pro";
                    price= "$999";
                }
                else if (ip13pm.isChecked()){
                    type="Iphone 13 Pro Max";
                    price= "$1099";
                }
                else{
                    Toast.makeText(AppleActivity.this, "Please Select Phone Type", Toast.LENGTH_SHORT).show();
                }
                myRef1.setValue(type);
                myRef2.setValue(price);
                Intent in = new Intent(AppleActivity.this,activity_cartview.class);
                startActivity(in);
            }
        });

    }
}
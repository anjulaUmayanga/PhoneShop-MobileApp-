package com.item.phoneshop;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class SonyActivity extends AppCompatActivity {

    String type="";
    String price = "";
    Button addcart;
    RadioButton xp,x1,x5;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sony);

        addcart = findViewById(R.id.addcart);
        xp = findViewById(R.id.xp);
        x1 = findViewById(R.id.x1v);
        x5 = findViewById(R.id.x5v);

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef1 = database.getReference("type");
        DatabaseReference myRef2 = database.getReference("price");

        addcart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (xp.isChecked()){
                    type="Xperia PRO";
                    price= "$1799";

                }
                else if (x1.isChecked()){
                    type="Xperia 1 V";
                    price= "$1100";
                }
                else if (x5.isChecked()){
                    type="Xperia 5 V";
                    price= "$1600";
                }
                else{
                    Toast.makeText(SonyActivity.this, "Please Select Phone Type", Toast.LENGTH_SHORT).show();
                }
                myRef1.setValue(type);
                myRef2.setValue(price);
                Intent in = new Intent(SonyActivity.this,activity_cartview.class);
                startActivity(in);
            }
        });
    }
}
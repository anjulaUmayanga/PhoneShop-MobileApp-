package com.item.phoneshop;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class SamsungActivity extends AppCompatActivity {

    RadioButton s22u, s23, s23u;
    Button add;
    String type="",price="";
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_samsung);
        add = findViewById(R.id.addcart);
        s22u = findViewById(R.id.s22u);
        s23 = findViewById(R.id.s23);
        s23u = findViewById(R.id.s23u);

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef1 = database.getReference("type");
        DatabaseReference myRef2 = database.getReference("price");

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(s22u.isChecked()){
                    type="S 22 Ultra";
                    price="$1050";
                } else if (s23.isChecked()) {
                    type="S 23";
                    price = "$640";

                }
                else if (s23u.isChecked()) {
                    type="S 23 Ultra";
                    price = "$1020";

                }else{
                    Toast.makeText(SamsungActivity.this, "Please select Phone", Toast.LENGTH_SHORT).show();
                }
                myRef1.setValue(type);
                myRef2.setValue(price);
                Intent in = new Intent(SamsungActivity.this,activity_cartview.class);
                startActivity(in);
            }
        });
    }
}
package com.item.phoneshop;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class activity_cartview extends AppCompatActivity {

    ListView cartListView;
    List<String> cartItems;
    ArrayAdapter<String> arrayAdapter;
    Button deleteButton;

    int selectedPosition = AdapterView.INVALID_POSITION;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cartview);

        cartListView = findViewById(R.id.cartListView);
        deleteButton = findViewById(R.id.deleteButton);

        cartItems = new ArrayList<>();
        arrayAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, cartItems);
        cartListView.setAdapter(arrayAdapter);


        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference typeRef = database.getReference("type");
        DatabaseReference priceRef = database.getReference("price");

        typeRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String type = dataSnapshot.getValue(String.class);
                if (type != null) {
                    priceRef.addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            String price = snapshot.getValue(String.class);
                            if (price != null) {
                                String item = type + " - $" + price;
                                if (!cartItems.contains(item)) {
                                    cartItems.add(item);
                                    arrayAdapter.notifyDataSetChanged();
                                }
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {
                            Toast.makeText(activity_cartview.this, "Failed to read price.", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(activity_cartview.this, "Failed to read type.", Toast.LENGTH_SHORT).show();
            }
        });


        cartListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                selectedPosition = position;
                Toast.makeText(activity_cartview.this, "Item selected.", Toast.LENGTH_SHORT).show();
            }
        });


        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (selectedPosition != AdapterView.INVALID_POSITION) {
                    String selectedItem = cartItems.get(selectedPosition);
                    String[] parts = selectedItem.split(" - ");
                    String selectedType = parts[0];


                    typeRef.setValue(null);
                    priceRef.setValue(null);


                    cartItems.remove(selectedItem);
                    arrayAdapter.notifyDataSetChanged();

                    selectedPosition = AdapterView.INVALID_POSITION;

                    Toast.makeText(activity_cartview.this, "Item removed from the cart.", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(activity_cartview.this, "Please select an item to delete.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}

package com.item.phoneshop;

import androidx.appcompat.app.AppCompatActivity;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {

    Button log, create;
    TextView tv;

    String password="",name="",getname="",getpw="";
    EditText nameobj,pwobj;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        log = findViewById(R.id.log);
        create = findViewById(R.id.create);

        nameobj =(EditText) findViewById(R.id.uname);
        pwobj = (EditText) findViewById(R.id.pw);

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef1 = database.getReference("Name");
        DatabaseReference myRef2 = database.getReference("Password");

        create.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(MainActivity.this, CreateActivity.class);
                startActivity(in);
            }
        });

        log.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                myRef1.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {

                        Object nameObject = dataSnapshot.getValue();


                        if (nameObject != null) {
                             name = nameObject.toString();



                        }
                    }

                    @Override
                    public void onCancelled(DatabaseError error) {

                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {

                                Toast.makeText(MainActivity.this, "Failed to read values.", Toast.LENGTH_SHORT).show();

                            }
                        });
                    }
                });


                myRef2.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {

                        Object passwordObject = dataSnapshot.getValue();


                        if (passwordObject != null) {
                             password = passwordObject.toString();




                        }
                    }

                    @Override
                    public void onCancelled(DatabaseError error) {

                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {

                                Toast.makeText(MainActivity.this, "Failed to read password.", Toast.LENGTH_SHORT).show();
                            }
                        });
                    }
                });
               getname= nameobj.getText().toString();
               getpw = pwobj.getText().toString();


               if(getname.equals(name) && getpw.equals(password) ){
                   Intent intent = new Intent(MainActivity.this,SaleActivity.class);
                   startActivity(intent);

               }



            }

        });

    }
}
